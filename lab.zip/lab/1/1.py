import csv
import numpy as np
import matplotlib.pyplot as plt


wl=[]
bl=[]
cl=[]
ion=[]
bcw=[]

def getion():
	f_csv="ion.csv"
	fo=open(f_csv,"r")
	reader = csv.reader(fo)
	for row in reader:
	    ion.append( list(row[i] for i in range(0,35) ) ) #elemt of x is string format not in int format
	fo.close()

def getbcw():
	f_csv="bcw.csv"
	fo=open(f_csv,"r")
	reader = csv.reader(fo)
	for row in reader:
	    bcw.append( list(row[i] for i in range(1,11) ) ) #elemt of x is string format not in int format
	fo.close()

def voted_bcw(epo,lo,hi): #calultion rows r BETWEEN lo <= r < hi
	n=1
	w = np.array([0,0,0,0,0,0,0,0,0])
	b=0
	c=0

	for epochs in range(0,epo):
		cnt=1
		for row in bcw:
			if not(cnt>=lo and cnt<hi):
			    content = row
			    content  = map(float, content)
			    x = np.asarray(content[0:9])
			    y = content[9]
			    if y==2:
			    	y=-1
			    else:
			    	y=1

			    if y*(np.dot(w,x)+b)<=0:
			    	if c!=0:
			    		wl.append(w)
			    		bl.append(b)
			    		cl.append(c)
			    	n=n+1
			    	w=w+y*x
			    	b=b+y
			    	c=1
			    else:
			    	c+=1
			cnt+=1

		wl.append(w)
		bl.append(b)
		cl.append(c)

	# sum=0


	# for i in range(0,len(wl)):
	# 	print "w:",wl[i],"b:",bl[i],"c:",cl[i]


	# 	sum+=cl[i]

	# print sum,len(wl)

def vanilla_bcw(epo,lo,hi):
	n=1
	w = np.array([0,0,0,0,0,0,0,0,0])
	b=0

	for epochs in range(0,epo):
		cnt=1
		for row in bcw:
			if not(cnt>=lo and cnt<hi):
			    content = row
			    content  = map(float, content)
			    x = np.asarray(content[0:9])
			    y = content[9]
			    if y==2:
			    	y=-1
			    else:
			    	y=1

			    if y*(np.dot(w,x)+b)<=0:
			    	w=w+y*x
			    	b=b+y
			cnt+=1
	wl.append(w)
	bl.append(b)


	# sum=0

	# for i in range(0,len(wl)):
	# 	print "w:",wl[i],"b:",bl[i]
	
	# 	sum+=cl[i]

	# print sum,len(wl)

def voted_ion(epo,lo,hi):
	no=1
	n=1
	w = np.array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
	b=0
	c=0
	for epochs in range(0,epo):
		cnt=1
		for row in ion:
			if not(cnt>=lo and cnt<hi):
			    content = row
			    y = content[34]
			    content  = map(float, content[0:34])
			    x = np.asarray(content)
			    if y=='g':
			    	y=1
			    else:
			    	y=-1

			    if y*(np.dot(w,x)+b)<=0:
			    	if c!=0:
			    		wl.append(w)
			    		bl.append(b)
			    		cl.append(c)
			    	n=n+1
			    	w=w+y*x
			    	b=b+y
			    	c=1
			    else:
			    	c+=1
			cnt+=1

		wl.append(w)
		bl.append(b)
		cl.append(c)

	#sum=0


	# for i in range(0,len(wl)):
	# 	print "w:",wl[i],"b:",bl[i],"c:",cl[i]
		

		#sum+=cl[i]

	#print sum,len(wl),n

def vanilla_ion(epo,lo,hi):
	w = np.array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
	b=0
	for epochs in range(0,epo):
		cnt=1
		for row in ion:
			if not(cnt>=lo and cnt<hi):
			    content = row
			    y = content[34]
			    
			    content  = map(float, content[0:34])
			    x = np.asarray(content)
			    if y=='g':
			    	y=1
			    else:
			    	y=-1

			    if y*(np.dot(w,x)+b)<=0:
			    	w=w+y*x
			    	b=b+y
			cnt+=1

	wl.append(w)
	bl.append(b)
	#sum=0


	# for i in range(0,len(wl)):
	# 	print "w:",wl[i],"b:",bl[i]
		

		#sum+=cl[i]

	#print sum,len(wl),n

getion()
getbcw()

# print "Vanilla & Voted Perceptron for epochs=10,15,..50"

# for e in range(10,55,5):
# 	print "epochs = ",e
# 	del wl[:]
# 	del bl[:]
# 	del cl[:]
# 	print "vanilla perceptron on breast cancer data"
# 	vanilla_bcw(e,-1,-1)
# 	for i in range(0,len(wl)):
# 		print "w:",wl[i],"b:",bl[i]

# 	del wl[:]
# 	del bl[:]
# 	del cl[:]
# 	print "Voted perceptron on breast cancer data"
# 	voted_bcw(e,-1,-1)
# 	for i in range(0,len(wl)):
# 		print "w:",wl[i],"b:",bl[i],"c:",cl[i]
	

# for e in range(10,55,5):
# 	del wl[:]
# 	del bl[:]
# 	del cl[:]
# 	print "vanilla perceptron on ion data"
# 	vanilla_ion(e,-1,-1)
# 	for i in range(0,len(wl)):
# 		print "w:",wl[i],"b:",bl[i]


# 	del wl[:]
# 	del bl[:]
# 	del cl[:]
# 	print "Voted perceptron on ion data"
# 	voted_ion(e,-1,-1)
# 	for i in range(0,len(wl)):
# 		print "w:",wl[i],"b:",bl[i],"c:",cl[i]
	

ion_van=[]
ion_vot=[]
bcw_van=[]
bcw_vot=[]



print ""
print "Vanilla Perceptron (breast cancer data)"
for e in range(10,55,5):
	avg_succ=0
	for z in range(0,10):
		succ_cnt=0
		del wl[:]
		del bl[:]
		del cl[:]
		vanilla_bcw(e,z*68+1,(z+1)*68+1)
		
		for i in range(z*68+1,(z+1)*68+1):
			content = bcw[i]
			content  = map(float, content)
			x = np.asarray(content[0:9])
			y = content[9]
			if y==2:
				y=-1
			else:
				y=1

			if y*(np.dot(wl[0],x)+bl[0])>0:
				succ_cnt+=1
		print "k=",z," Sucess rate: ",(succ_cnt*100)/68
		avg_succ+=(succ_cnt*100)/68
	print "avg succ rate: ",avg_succ/10
	bcw_van.append([avg_succ/10])



print ""
print "Voted Perceptron (breast cancer data)"

for e in range(10,55,5):
	avg_succ=0
	for z in range(0,10):
		succ_cnt=0
		del wl[:]
		del bl[:]
		del cl[:]
		voted_bcw(e,z*68+1,(z+1)*68+1)
		
		for i in range(z*68+1,(z+1)*68+1):
			content = bcw[i]
			content  = map(float, content)
			x = np.asarray(content[0:9])
			y = content[9]
			if y==2:
				y=-1
			else:
				y=1


			ck=0
			for j in range(0,len(wl)):
				if (np.dot(wl[j],x)+bl[j])>0:
					ck+=cl[j]
				else:
					ck-=cl[j]
			if (ck*y)>0:
				succ_cnt+=1
		print "k=",z," Sucess rate: ",(succ_cnt*100)/68
		avg_succ+=(succ_cnt*100)/68
	print "avg succ rate: ",avg_succ/10
	bcw_vot.append([avg_succ/10])








print ""
print "Vanilla Perceptron (ion data)"

for e in range(10,55,5):
	avg_succ=0
	for z in range(0,10):
		succ_cnt=0
		del wl[:]
		del bl[:]
		del cl[:]
		vanilla_ion(e,z*35+1,(z+1)*35+1)
		
		for i in range(z*35+1,(z+1)*35+1):
			content = ion[i]
			y = content[34]
			content  = map(float, content[0:34])
			x = np.asarray(content)
			if y=='g':
				y=1
			else:
				y=-1

			if y*(np.dot(wl[0],x)+bl[0])>0:
				succ_cnt+=1
		print "k=",z," Sucess rate: ",(succ_cnt*100)/35
		avg_succ+=(succ_cnt*100)/35
	print "avg succ rate: ",avg_succ/10
	ion_van.append([avg_succ/10])



print ""
print "Voted Perceptron (ion data)"

for e in range(10,55,5):
	avg_succ=0
	for z in range(0,10):
		succ_cnt=0
		del wl[:]
		del bl[:]
		del cl[:]
		voted_ion(e,z*35+1,(z+1)*35+1)
		
		for i in range(z*35+1,(z+1)*35+1):
			content = ion[i]
			y = content[34]
			content  = map(float, content[0:34])
			x = np.asarray(content)
			if y=='g':
				y=1
			else:
				y=-1


			ck=0
			for j in range(0,len(wl)):
				if (np.dot(wl[j],x)+bl[j])>0:
					ck+=cl[j]
				else:
					ck-=cl[j]
			if (ck*y)>0:
				succ_cnt+=1
		print "k=",z," Sucess rate: ",(succ_cnt*100)/35
		avg_succ+=(succ_cnt*100)/35
	print "avg succ rate: ",avg_succ/10
	ion_vot.append([avg_succ/10])


print bcw_vot
print bcw_van
print ion_vot
print ion_van


ep=[10,15,20,25,30,35,40,45,50]
plt.plot(ep, bcw_vot, 'r--', ep, bcw_van, 'b--')
plt.show()



plt.plot(ep, ion_vot, 'r--', ep, ion_van, 'b--')
plt.show()