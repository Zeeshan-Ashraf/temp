import numpy as np
import matplotlib.pyplot as plt

N = 50
t = [1,2,3,4,5,6,7,8,9]
t2 = [2,4,6,8,10,12,14,16,18]
y = np.random.rand(N)

plt.plot(t, t, 'r--', t, t2, 'bs')
plt.show()


plt.plot(t, t, 'r--', t, t2, 'bs')
plt.show()