#include <iostream>
using namespace std;

int N;
int MaxSum;
// Customers
// a -> Arrival Time
// d -> Duration Time
// mp -> Maximum Points
struct cust{
	int a, d, mp;
};
// Advertisements
// l -> length of the Ad
// p -> Points
// bt -> Broadcasted at Start Time
struct add{
	int l, p, bt;
};

cust C[55];
add A[4];

void maximize(){
	// it -> In Time // et -> Exit Time
	// st -> Start Time // ft -> Finish Time
	for(int i=1; i<=N; i++){
		int it = C[i].a;
		int et = C[i].a + C[i].d;
		for(int j=1; j<=3; j++){
			int st = A[j].bt;
			int ft = A[j].bt + A[j].l;
			if(it <= st && ft <= et){
				if(C[i].mp < A[j].p )
					C[i].mp = A[j].p;
			}
		}
	}
}
// For each Permuation resetting values
void clear(){
	for(int i=1; i<=N; i++){
		C[i].mp = 0;
	}
}
// Calculating to check max value for each Permuation
void calMax(){
	int sum=0;
	for(int i=1; i<=N; i++){
		sum += C[i].mp;
	}
	if(sum > MaxSum)
		MaxSum = sum;
}
// Broadcasting Ads using BLE
void beacon(int a, int b, int c){

	int t1, t2, t3;
	for(int i=1; i<=50; i++){
		A[a].bt = i;
		t1 = A[a].bt + A[a].l;
		for(int j=t1; j<=50; j++){
			A[b].bt = j;
			t2 = A[b].bt + A[b].l;
			for(int k=t2; k<=50; k++){
				A[c].bt = k;
				t3 = A[c].bt + A[c].l;// For Future use in case of 4 Ads :P
				clear();
				maximize();
				calMax();
			}
		}
	}
}

int solve(){
	// Permutations
	for(int a=1; a<=3; a++){
		for(int b=1; b<=3; b++){
			for(int c=1; c<=3; c++){
				if(a!=b && b!=c && c!=a){
					beacon(a, b, c);
				}
			}
		}
	}
	// Result, which is Global Maximum
	return MaxSum;
}

int main(int argc, char** argv){

	int T;
	cin >> T;

	for(int tc=1; tc<=T; tc++){
		cin >> N;
		MaxSum = 0;
		// Lengths
		for(int i=1; i<=3; i++){
			cin >> A[i].l;
		}
		// Points
		for(int i=1; i<=3; i++){
			cin >> A[i].p;
		}
		// Customers
		for(int i=1; i<=N; i++){
			cin >> C[i].a >> C[i].d;
			//cout << C[i].a << " " << C[i].d <<endl;
		}
		cout << "#" << tc << " " << solve() << endl;
	}
	return 0;
}