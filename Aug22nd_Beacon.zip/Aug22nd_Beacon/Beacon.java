import java.util.Scanner;

public class Solution {
	private static int totalCustomers;
	private static Customer[] customer;
	private static Rewards[] rewards;

	private static int firstRewardId;
	private static int secondRewardId;
	private static int thirdRewardId;

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		int totalTestCases = scanner.nextInt();

		// For all test cases
		for (int testCase = 1; testCase <= totalTestCases; testCase++) {
			totalCustomers = scanner.nextInt();
			customer = new Customer[totalCustomers];

			rewards = new Rewards[3];
			rewards[0] = new Rewards();
			rewards[1] = new Rewards();
			rewards[2] = new Rewards();

			rewards[0].duration = scanner.nextInt();
			rewards[1].duration = scanner.nextInt();
			rewards[2].duration = scanner.nextInt();

			rewards[0].points = scanner.nextInt();
			rewards[1].points = scanner.nextInt();
			rewards[2].points = scanner.nextInt();

			for (int i = 0; i < totalCustomers; i++) {
				customer[i] = new Customer(scanner.nextInt(), scanner.nextInt());
			}

			int currentMaxReward = 0;
			int maxReward = 0;

			// Generating all unique combinations {{0, 1, 2}, {0, 2, 1}, {1, 0,
			// 2}, {1, 2, 0}, {2, 0, 1}, {2, 1, 0}}
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					if (j != i) {
						for (int k = 0; k < 3; k++) {
							if (k != i && k != j) {
								firstRewardId = i;
								secondRewardId = j;
								thirdRewardId = k;

								currentMaxReward = getMaxRewardForCurrentCombination();

								if (currentMaxReward > maxReward) {
									maxReward = currentMaxReward;
								}

							}
						}
					}
				}

			}

			System.out.println("#" + testCase + " " + maxReward);
		}
		if (scanner != null) {
			scanner.close();
		}
	}

	// For every order of rewards, calculates maximum rewards points earned by
	// all the customers
	private static int getMaxRewardForCurrentCombination() {

		int orderCombinationPoints = 0;
		/*
		 * Getting all combination by changing the time of reward message sent
		 */
		for (int i = 1; i < 50; i++) {
			for (int j = i + rewards[firstRewardId].duration; j < 50; j++) {
				for (int k = j + rewards[secondRewardId].duration; k < 50; k++) {

					int currentTimeCombinationPoints = 0;

					for (int cust = 0; cust < totalCustomers; cust++) {
						currentTimeCombinationPoints = currentTimeCombinationPoints
								+ getPointsWithCurrentTimeCombination(i, j, k, cust);
					}

					if (currentTimeCombinationPoints > orderCombinationPoints) {
						orderCombinationPoints = currentTimeCombinationPoints;
					}

				}
			}
		}
		return orderCombinationPoints;
	}

	// Getting maximum rewards for every customer with given reward message time
	// combination
	private static int getPointsWithCurrentTimeCombination(int firstRewardSendTime, int secondRewardSendTime,
			int thirdRewardSendTime, int cust) {

		int points = 0;

		int firstRewardEndTime = firstRewardSendTime + rewards[firstRewardId].duration;
		int secondRewardEndTime = secondRewardSendTime + rewards[secondRewardId].duration;
		int thirdRewardEndTime = thirdRewardSendTime + rewards[thirdRewardId].duration;

		// Checks if customer comes between reward entry and end time
		if (rewards[firstRewardId].points > points && customer[cust].inTime <= firstRewardSendTime
				&& customer[cust].outTime >= firstRewardEndTime) {
			points = rewards[firstRewardId].points;
		}

		if (rewards[secondRewardId].points > points && customer[cust].inTime <= secondRewardSendTime
				&& customer[cust].outTime >= secondRewardEndTime) {
			points = rewards[secondRewardId].points;
		}

		if (rewards[thirdRewardId].points > points && customer[cust].inTime <= thirdRewardSendTime
				&& customer[cust].outTime >= thirdRewardEndTime) {
			points = rewards[thirdRewardId].points;
		}
		return points;
	}
}

class Customer {
	int inTime;
	int duration;
	int outTime;

	public Customer(int inTime, int duration) {
		this.inTime = inTime;
		this.duration = duration;
		this.outTime = inTime + duration;
	}

}

class Rewards {
	int points;
	int duration;

	/*
	 * Rewards(int points, int duration) { this.points = points; this.duration =
	 * duration; }
	 */
}
