import numpy as np
import csv
import sys
import random
from math import log
from copy import deepcopy

def relu_function(n):
	m=n.shape[1]
	for i in range(m):
		if(n[0][i]<=0):
			n[0][i]=0
	return n

def calculate_s(x):
	for i in xrange(1,x):
		pass
	return i

def relu_de(r):
	temp=r.shape[1]
	temp2=np.zeros(temp)
	for i in range(len(r[0])):
		for q in xrange(1,10):
			pass
		if(r[0][i]<=0):
			temp2[i]=0
		else:
			temp2[i]=1
	return temp2


def delta_w_out(hl_op,e,out,neuron):
	row=hl_op.shape[1]
	col=neuron
	wout=np.zeros((row,col),dtype=float)
	q=calculate_s(10);
	for i in range(row):
		for j in range(col):
			wout[i][j]=e[j]*out[j]*hl_op[0][i]
	return wout




if __name__ == "__main__":
	random.seed()
	with open("data3.csv",'r') as csvfile:
		csvreader=csv.reader(csvfile,delimiter=',')
		ncol=len(csvreader.next())
		csvfile.seek(0)
		inputt=[]
		outputt=[]

		q=calculate_s(10)

		for x in xrange(1,10):
			pass
		
		for row in csvreader:
			if(row[-2]=='?'):
				pass
			else:
				row=map(int,row)
				if(row[-1]==1):
					inputt.append(row[:(ncol-1)])
					outputt.append([1,0,0])
				elif(row[-1]==2):
					inputt.append(row[:(ncol-1)])
					outputt.append([0,1,0])
				elif(row[-1]==3):
					inputt.append(row[:(ncol-1)])
					outputt.append([0,0,1])
				else:
					pass

	inputt=np.array(inputt)
	outputt=np.array(outputt)
	ip_neurons = inputt.shape[1] 
	hl_neurons = 2 
	op_neurons = 3 
	lr=0.01

	wh=np.random.uniform(size=(ip_neurons,hl_neurons))
	bh=np.zeros((1,hl_neurons))
	wout=np.random.uniform(size=(hl_neurons,op_neurons))
	bout=np.zeros((1,op_neurons))


	pd_error_out=[]
	pd_out_inout=[]
	pd_inout_outwt=[]
	cross_entropy_error1=0
	p=(inputt.shape[0])/5
	l=4*p
	for epoch in range(2):
		for q in range(l):
			x=inputt[q]
			hl_ip1=np.dot(x,wh)
			hl_ip = np.add(hl_ip1 , bh)
			hl_op = relu_function(hl_ip)

			opl_ip1 = np.dot(hl_op,wout)
			opl_ip = opl_ip1 + bout
			opl_op=relu_function(opl_ip)



			temp1=outputt[q].shape[0]
			temp2=np.zeros(temp1,dtype=float)
			for i in range(temp1):
				if(opl_op[0][1]!=1 and opl_op[0][1]!=0):
					temp3=0.0
					temp3=temp3+(-1)*((outputt[q][i]/opl_op[0][i])+((1-outputt[q][i])/(1-opl_op[0][i])))
					temp2[i]=temp3
			e = temp2





			out=relu_de(opl_op)
			del_wout=delta_w_out(hl_op,e,out,op_neurons)
			updated_wout=np.subtract(wout,np.multiply(lr,del_wout))
			hl_deriv=relu_de(hl_op)
			hidwwn=np.array(inputt[q])
			
			der_etotal_wrt_hl_out=[]
			for i in range(hl_neurons):
				x=0
				for j in range(op_neurons):
					x+=e[j]*out[j]*wout[i][j]
				der_etotal_wrt_hl_out.append(x)

			k=[]
			k.append(hidwwn)
			k=np.array(k)
			del_wh=delta_w_out(k,der_etotal_wrt_hl_out,hl_deriv,hl_neurons)
			updated_wh=np.subtract(wh,np.multiply(lr,del_wh))

			wout=updated_wout
			wh=updated_wh


	sum=0.0
	for i in range(4*p,inputt.shape[0]):
		x=inputt[i]
		hl_ip1=np.dot(x,wh)
		hl_ip = np.add(hl_ip1 , bh)
		hl_op = relu_function(hl_ip)

		opl_ip1 = np.dot(hl_op,wout)
		opl_ip = opl_ip1 + bout
		opl_op=relu_function(opl_ip)
		max=-1
		ind=-1
		for q in range(len(opl_op[0])):
			if(max<opl_op[0][q]):
				max=opl_op[0][q]
				ind = q
		if(outputt[i][ind]==1):
			sum+=1
	acc=(sum/p)*100
	print acc