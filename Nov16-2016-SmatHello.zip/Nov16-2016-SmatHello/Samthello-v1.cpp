// Samthello.cpp : Defines the entry point for the console application.
//Shilpa S Kavasseri

#include "stdafx.h"
#include<iostream>
using namespace std;

int coins[100];
int tempArr[100];
int N;

// A function to flip the coins based on the given set of rules
void play(int color, int index){
	int flag = -1;
	//flag = -1 when the loop has reached till index =0 or index = N
	//flag = 0 when it finds a 0
	//flag = 1 when it finds a black
	//flag = 2 when it finds a white

	if (color == 1){                                   //flip the coins when the current player is black =1
		int left = 0;
		int right = 0;

		for (int i = index - 1; i >= 0; i--){     // to compute coins to the left of current player position
			if (tempArr[i] == 2)
				continue;
			else if (tempArr[i] == 1){
				left = i + 1;
				flag = 1;
				break;
			}
			else if (tempArr[i] == 0){
				flag = 0;
				break;
			}
		}
		if (flag == 1){                          // the current player is bounded by black to its left
			for (int i = left; i < index; i++)
				tempArr[i] = 1;         // flip all white coins to black lying b/w the current position & left most black coin          
		}
		else if (flag == -1){                   //all the coins to the left of current position is white
			for (int i = 0; i < index; i++){
				tempArr[i] = 1;         // flip all white coins to black from index  0 to current position
			}
		}

		flag = -1;
		for (int i = index + 1; i <N; i++){       // to compute coins to the right of current player position
			if (tempArr[i] == 2)
				continue;
			else if (tempArr[i] == 1){
				right = i - 1;
				flag = 1;
				break;
			}
			else if (tempArr[i] == 0){
				flag = 0;
				break;
			}

		}
		if (flag == 1){                        // the current player is bounded by black to its right                      
			for (int i = index + 1; i <= right; i++)
				tempArr[i] = 1;        // flip all white coins to black lying b/w the current position & right  most black coin  
		}
		if (flag == -1){                      //all the coins to the right of current position is white
			for (int i = index + 1; i <N; i++)
				tempArr[i] = 1;     //flip all white coins to black from current position to index N
		}

	}
	if (color == 2){                           // flip the coins when the current player is white
		int left = 0;
		int right = 0;
		flag = -1;
		for (int i = index - 1; i >= 0; i--){
			if (tempArr[i] == 1)
				continue;
			else if (tempArr[i] == 2){
				left = i + 1;
				flag = 2;
				break;
			}
			else if (tempArr[i] == 0){
				flag = 0;
				break;
			}
		}
		if (flag == 2){
			for (int i = left; i < index; i++)
				tempArr[i] = 2;
		}
		else if (flag == -1){
			for (int i = 0; i < index; i++){
				tempArr[i] = 2;
			}
		}

		flag = -1;
		for (int i = index + 1; i <N; i++){
			if (tempArr[i] == 1)
				continue;
			else if (tempArr[i] == 2){
				right = i - 1;
				flag = 2;
				break;
			}
			else if (tempArr[i] == 0){
				flag = 0;
				break;
			}

		}
		if (flag == 2){
			for (int i = index + 1; i <= right; i++)
				tempArr[i] = 2;
		}
		if (flag == -1){
			for (int i = index + 1; i <N; i++)
				tempArr[i] = 2;
		}

	}

}


int main()
{
	int T;
	cin >> T;
	for (int testCase = 0; testCase < T; testCase++){
		cin >> N;
		for (int i = 0; i < N; i++)
			cin >> coins[i];
		int maxScore = 0;

		//nested for loops to generate various combinations for black player
		for (int i = 0; i < N; i++){
			for (int j = 0; j < N; j++){
				for (int k = 0; k < N; k++){
					for (int s = 0; s < N; s++)
						tempArr[s] = coins[s]; // copy the initial array to temp array
					if (tempArr[i] == 0){          // black , chance 1
						tempArr[i] = 1;
						play(1, i);           // function to flip the coins
					}
					else
						continue;
					for (int s = 0; s < N; s++){  // place the white coin in the first left most blank space, chance 1
						if (tempArr[s] == 0){
							tempArr[s] = 2;
							play(2, s);
							break;
						}
					}
					if (tempArr[j] == 0){      //black chance 2
						tempArr[j] = 1;
						play(1, j);
					}
					else
						continue;
					for (int s = 0; s < N; s++){ //white chance 2
						if (tempArr[s] == 0){
							tempArr[s] = 2;
							play(2, s);
							break;
						}
					}
					if (tempArr[k] == 0){       //black chance 3
						tempArr[k] = 1;
						play(1, k);
					}
					else
						continue;
					for (int s = 0; s < N; s++){ //white chance 3
						if (tempArr[s] == 0){
							tempArr[s] = 2;
							play(2, s);
							break;
						}
					}
					int blackCount = 0;
					for (int s = 0; s < N; s++){  // to count num of black coins
						if (tempArr[s] == 1)
							blackCount++;
					}
					if (maxScore < blackCount)   // to find maxScore for a given game board
						maxScore = blackCount;

				}
			}
		}
		cout << "#" << testCase + 1 << " " << maxScore << endl;

	}
	return 0;
}