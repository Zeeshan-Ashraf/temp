package FishingSpot;   //Mohd Abdul Qaathir
import java.util.Scanner;
public class FishingSpot {

    /**
     * @param args
     */
	//global variable to store the results
    static int gsum=1000000000;
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner sc=new Scanner(System.in);
        int tc=sc.nextInt();

        for(int t=1;t<=tc;t++)
        {
        	//number of spots
            int n=sc.nextInt();
            //array to store the order of the gates
            int gate[]=new int[3];
            //array to store in which direction the persons will be filled in the spots it has values of 0's and 1's
            //0-fill right then left
            //1-fill left then right
            int order[]=new int[3];
            
            //number of persons in each gate
            int person[]=new int[3];
            
            //start location number for each gate
            int location[]=new int[3];
            
            for(int i=0;i<3;i++)
            {
                location[i]=sc.nextInt()-1;
                person[i]=sc.nextInt();
            }
            
            //6 for loops will determine the order of the gates and the order in which each person in the gate will be alloted in the spots
            for(int i=0;i<3;i++)
            {
            	for(int j=0;j<3;j++)
                {
            		if(i==j)
            			continue;
            		for(int k=0;k<3;k++)
                    {
            			if(i==k || j==k)
            				continue;
            			gate[0]=i;
            			gate[1]=j;
            			gate[2]=k;
            			for(int l=0;l<2;l++)
                        {
            				for(int m=0;m<2;m++)
            	            {
            					for(int p=0;p<2;p++)
            		            {
            						order[0]=l;
            						order[1]=m;
            						order[2]=p;
            						//a function which returns the answer
            						int sum=fun(gate,order,person,location,n);
            						//System.out.println(sum);
            						if(gsum>sum)
            							gsum=sum;
            		            }
            	            }
                        }
                    }
            			
                    }
                }
            
            System.out.println("#"+t+" "+gsum);
            gsum=1000000000;
            }
        sc.close();
    }

    public static int fun(int gate[],int order[],int person[],int location[],int n)
    {
    	int sum=0;
    	int visited[]=new int[n];
    	for(int i=0;i<3;i++)
        {
        	for(int j=0;j<3;j++)
            {
        	if(gate[j]==i)
        	{
        		if(order[j]==0)
        		{
        			//this function allocates the person first right and then left
        			sum=sum+allocate_right(person[j],location[j],n,visited);
        		}
        		else
        		{
        			//this function allocates the person first left and then right
        			sum=sum+allocate_left(person[j],location[j],n,visited);
        		}
        		}
        		
        	}		
       }
    	return sum;
    }
    
    public static int allocate_right(int person,int location,int n,int visited[])
    {
    	int sum=0;
    	if(visited[location]==0)
    	{
    		sum=sum+1;
    		visited[location]=1;
    		person=person-1;
    	}
    	for(int i=0;i<n;i++)
    	{
    		if(person==0)
    			break;
    		int add=location+i;
    		int sub=location-i;
    		if(add<n&&person>0&&visited[add]==0)
    		{
    			sum=sum+i+1;
    			visited[add]=1;
        		person=person-1;
    		}
    		if(sub>=0&&person>0&&visited[sub]==0)
    		{
    			
    			sum=sum+i+1;
    			visited[sub]=1;
        		person=person-1;
    			
    		}
    	}
    	
    return sum;	
    }
    
    
    public static int allocate_left(int person,int location,int n,int visited[])
    {
    	int sum=0;
    	if(visited[location]==0)
    	{
    		sum=sum+1;
    		visited[location]=1;
    		person=person-1;
    	}
    	for(int i=0;i<n;i++)
    	{
    		if(person==0)
    			break;
    		int add=location+i;
    		int sub=location-i;
    		if(sub>=0&&person>0&&visited[sub]==0)
    		{
    			
    			sum=sum+i+1;
    			visited[sub]=1;
        		person=person-1;
    			
    		}
    		if(add<n&&person>0&&visited[add]==0)
    		{
    			sum=sum+i+1;
    			visited[add]=1;
        		person=person-1;
    		}	
    	}
    	
    return sum;	
    }
}
/*
5   // No.of.Testcase
10   //total no.of.locations
4 5     //gate 1 at 4 is gate no.   5 is queue size of gate
6 2		//gate 2
10 2	//gate 3
10
8 5
9 1
10 2
24
15 3
20 4
23 7
39
17 8
30 5
31 9
60
57 12
31 19
38 16
*/
