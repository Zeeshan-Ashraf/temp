import java.util.Scanner;	//Anjani Gujja
public class FishingSpot {
    static int N,gate1,fishermen1,gate2,fishermen2,gate3,fishermen3,min,temp;
    static int[] fishingSpots;
    static int[][] gate_fmencount;
    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
        int tc=sc.nextInt();
        gate_fmencount=new int[3][2];
        for(int t=1;t<=tc;t++)
        {
            N=sc.nextInt();
            min=999999;
	//Storing the Gate Number and Fishermen Count
            for(int i=0;i<3;i++)
            {
                gate_fmencount[i][0]=sc.nextInt();
                gate_fmencount[i][1]=sc.nextInt();
            }
	//To get 6 combinations of choosing the 3 Gates
            for(int i=1;i<4;i++)
            {
                for(int j=1;j<4;j++)
                {
                    for(int k=1;k<4;k++)
                    {
                        if(i+j+k==6 && i!=j && i!=k && j!=k)
                        {
                            gate1=gate_fmencount[i-1][0];
                            fishermen1=gate_fmencount[i-1][1];

                            gate2=gate_fmencount[j-1][0];
                            fishermen2=gate_fmencount[j-1][1];

                            gate3=gate_fmencount[k-1][0];
                            fishermen3=gate_fmencount[k-1][1];

                            findSpots();
                        }
                    }
                }
            }
            System.out.println("#"+t+" "+min);
        }

        sc.close();
    }

    private static void findSpots() {
        // TODO Auto-generated method stub

// I will either start placing the fishermen at the right side first or left side first ( 0: Left, 1: Right)
        for(int i=0;i<=1;i++)
        {
            for(int j=0;j<=1;j++)
            {
                for(int k=0;k<=1;k++)
                {
                    fishingSpots=new int[N+1];
                    getDistance(i,j,k,fishingSpots);
                }
            }
        }
    }

    private static void getDistance(int i, int j, int k,int[] fishingSpots) {
        // TODO Auto-generated method stub
        int temp=0;

        if(i==0)
            goLeftFirst(fishingSpots,fishermen1,gate1);
        else
            goRightFirst(fishingSpots,fishermen1,gate1);

        if(j==0)
            goLeftFirst(fishingSpots,fishermen2,gate2);
        else
            goRightFirst(fishingSpots,fishermen2,gate2);

        if(k==0)
            goLeftFirst(fishingSpots,fishermen3,gate3);
        else
            goRightFirst(fishingSpots,fishermen3,gate3);

//Add the total distances
        for(int a=1;a<N+1;a++)
            temp+=fishingSpots[a];

//Check the distance if it is lesser than previous ones
        if(min>temp)
            min=temp;

    }

    private static void goRightFirst(int[] fishingSpots, int fishermen, int gateNumber) {
        // TODO Auto-generated method stub
        int menCount=fishermen;
        int gate=gateNumber;
//If the Gate position is not yet occupied by any fisherman
        if(fishingSpots[gate]==0)
        {
            fishingSpots[gate]=1;
            menCount--;
        }
        int left=1,right=1,leftDistance=2,rightDistance=2,position;
//Will start placing the fishermen at nearest position (start with placing him at right first and then left)
        while(menCount>0)
        {
            position=gate+right;
            if(position<=N && fishingSpots[position]==0)
            {
                fishingSpots[position]=rightDistance;
                menCount--;
            }
   
            position=gate-left;
            if(position>0 && fishingSpots[position]==0 && menCount>0)
            {
                fishingSpots[position]=leftDistance;
                menCount--;
            }
            left++;
			right++;
            rightDistance++;
            leftDistance++;
        }
    }

    private static void goLeftFirst(int[] fishingSpots,int fishermen,int gateNumber) {
        // TODO Auto-generated method stub
        int menCount=fishermen;
        int gate=gateNumber;
//If the Gate position is not yet occupied by any fisherman
        if(fishingSpots[gate]==0)
        {
            fishingSpots[gate]=1;
            menCount--;
        }
        int left=1,right=1,leftDistance=2,rightDistance=2,position;
//Will start placing the fishermen at nearest position (start with placing him at left first and then right
        while(menCount>0)
        {
            position=gate-left;
            if(position>0 && fishingSpots[position]==0)
            {
                fishingSpots[position]=leftDistance;
                menCount--;
            }
            left++;
			leftDistance++;
            position=gate+right;
            if(position<=N && fishingSpots[position]==0 && menCount>0)
            {
                fishingSpots[position]=rightDistance;
                menCount--;
            }
            right++;
            rightDistance++;
        }
    }
}
