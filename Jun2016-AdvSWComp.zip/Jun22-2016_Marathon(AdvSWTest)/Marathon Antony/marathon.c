#include<stdio.h>
#include<conio.h>

struct PACE{
	int t;  //pace time
	int c;  // pace calorie
};

struct PACE P[5]; //since there are 5 paces only
int H,D; // H- Total Energy, D- Total Dist




/*Since the max distance that go is only up to 40
the below for loop will execute 40*40*40*40*40 = 1024 * 100000 = ~ 10 power of 8
This can run with in 1 sec.
However the Limit given in test is < 3 secs

The below logic will work
*/

int CheckRecordTime()
{
	int a,b,c,d,e;  //each for PACE[i]'s combination
	int time;
	int cal;
	int mintime=9999999;

	for(a=0;a<=D;a++)
	{
		for(b=0;b<=D;b++)
		{
			for(c=0;c<=D;c++)
			{
				for(d=0;d<=D;d++)
				{
					for(e=0;e<=D;e++)
					{
						if(a+b+c+d+e==D)
						{
							time=P[0].t*a+P[1].t*b+P[2].t*c+P[3].t*d+P[4].t*e;
							cal=P[0].c*a+P[1].c*b+P[2].c*c+P[3].c*d+P[4].c*e;

							if(cal<=H)
							{
								if(time<mintime)
									mintime=time;
							}
						}

						
					}
				}
			}
		}
	}

	return(mintime);
}



int main()
{
	int time_m,time_s,cal;
 
	int i;
	int ans;
	int T; //no of TC
	int k; // iteration for TC

	scanf("%d",&T);

for(k=1;k<=T;k++)
{
	//reading i/ps
	scanf("%d %d",&H,&D);

	for(i=0;i<5;i++)
	{
		scanf("%d %d %d",&time_m,&time_s,&cal);
		P[i].t=time_m*60 + time_s;
		P[i].c=cal;
	}

	//check for record time
	ans= CheckRecordTime();
	time_m = ans / 60;
	time_s = ans % 60;

	printf("#%d %d %d\n",k,time_m,time_s);
}
	getch();
}