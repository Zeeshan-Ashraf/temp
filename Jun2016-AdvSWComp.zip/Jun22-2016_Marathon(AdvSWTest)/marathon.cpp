#include<bits/stdc++.h>
using namespace std;

int main(){
	int z;
	clock_t start, end;
	double cpu_time_used;
	cin>>z;
	while(z--){
		int d,sam;
		cin>>d>>sam;
		int t[5],ans=100000;
		for(int i=0;i<5;i++) cin>>t[i];
		int e[5];
		for(int i=0;i<5;i++) cin>>e[i];

		start = clock();
		for(int i=0;i<=d;i++){
			for(int j=0;j<=d-i;j++){
				for(int k=0;k<=d-i-j;k++){
					for(int l=0;l<=d-i-j-k;l++){
						int m=d-i-j-k-l;
						int ee=i*e[0]+j*e[1]+k*e[2]+l*e[3]+m*e[4];
						int tt=i*t[0]+j*t[1]+k*t[2]+l*t[3]+m*t[4];
						if(ee<=sam){
							ans=min(ans,tt);
						}
					}
				}
			}
		}
		cout<<ans<<endl;
	}
	end = clock();
	cpu_time_used = ((double)(end-start))/CLOCKS_PER_SEC;
	cout<<cpu_time_used<<endl;
	return 0;
}