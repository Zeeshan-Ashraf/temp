#include <stdio.h>
#define DBG //printf
#define DBG1 //printf


typedef struct{

	int min;
	int sec;
	int E;
}pace;


int H,D;
pace run[5];
int dp_indx;
int run_count[6];
int max_sec =999999;
int Ans;

int findMinutes();
int pickup(int indx){

int i_cnt,j;
int Enrgy=0,secs=0,Dist=0;

for(i_cnt=1;i_cnt<=D;i_cnt++){


   run_count[indx+1]=i_cnt;
   Enrgy=0;secs=0;Dist=0;
   for(j=0;j<5;j++){
  
	   Enrgy += (run[j].E)* (run_count[j+1]);
       Dist += (run_count[j+1]);
	   secs += ((run[j].min * 60) + (run[j].sec))*(run_count[j+1]);
   }

   if(Enrgy > H || Dist > D) return 0;	
   
   if(Dist == D) {
   DBG1("\n Enrgy=%d dist=%d secs=%d",Enrgy,Dist,secs); 
   for(j=1;j<6;j++)DBG1(" %d",run_count[j]);
	   if(max_sec > secs )max_sec = secs;
	   return 0;
       
   }
   

	findMinutes();
	 

}



}



int findMinutes(){


int i,j;

for(i=0;i<5;i++){ // 5 paces

   if((dp_indx & (1<<i))!= 0) continue;

     dp_indx |= (1<<i); 
	 DBG("\n pickup=%d dpindx=%x",i,dp_indx);
	 pickup(i);	
	 dp_indx &= ~(1<<i);
	 DBG("\n unpickup=%d dpindx=%x",i,dp_indx);
     run_count[i+1] =0; //starts from 1 so +1

}

return max_sec;

}


int main(){
int T, test_case;
	int i,j,k;
	/*
	   The freopen function below opens input.txt file in read only mode, and afterward,
	   the program will read from input.txt file instead of standard(keyboard) input.
	   To test your program, you may save input data in input.txt file,
	   and use freopen function to read from the file when using scanf function.
	   You may remove the comment symbols(//) in the below statement and use it.
	   But before submission, you must remove the freopen function or rewrite comment symbols(//).
	 */
	 freopen("running_input.txt", "r", stdin);
	 freopen("output.txt", "w", stdout);

	/*
	   If you remove the statement below, your program's output may not be rocorded
	   when your program is terminated after the time limit.
	   For safety, please use setbuf(stdout, NULL); statement.
	 */
	setbuf(stdout, NULL);

	scanf("%d", &T);
	DBG("\n Testcase=%d",T);
	for(test_case = 0; test_case < T; test_case++)
	{
		scanf("%d %d", &H,&D);

		scanf("%d %d %d", &run[0].min,&run[0].sec,&run[0].E);
		scanf("%d %d %d", &run[1].min,&run[1].sec,&run[1].E);
		scanf("%d %d %d", &run[2].min,&run[2].sec,&run[2].E);
		scanf("%d %d %d", &run[3].min,&run[3].sec,&run[3].E);
		scanf("%d %d %d", &run[4].min,&run[4].sec,&run[4].E);

		DBG("\n H=%d D=%d P[1]-->[%d][%d][%d] P[2]-->[%d][%d][%d] P[3]-->[%d][%d][%d] P[4]-->[%d][%d][%d] P[5]-->[%d][%d][%d]", H,D,
			run[0].min,run[0].sec,run[0].E,
            run[1].min,run[1].sec,run[1].E,
			run[2].min,run[2].sec,run[2].E,
			run[3].min,run[3].sec,run[3].E,
			run[4].min,run[4].sec,run[4].E);

		


		//printf("\n");
		/////////////////////////////////////////////////////////////////////////////////////////////
		/*
		   Implement your algorithm here.
		   The answer to the case will be stored in variable Answer.
		 */
		/////////////////////////////////////////////////////////////////////////////////////////////
		

        for(j=0;j<6;j++)run_count[j]=0;
		Ans = findMinutes();
		printf("#%d %d %d\n", test_case+1,(Ans/60),(Ans%60));

		Ans=0;
		max_sec =999999;

		// Print the answer to standard output(screen).
		
		
	}
}
