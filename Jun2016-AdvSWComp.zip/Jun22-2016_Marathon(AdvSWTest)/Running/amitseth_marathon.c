
// In Practice, You should use the statndard input/output
// in order to receive a score properly.
// Do not use file input and output. Please be very careful. 

#include <stdio.h>
#include <conio.h>

typedef struct _t_ { int min; int sec; } ttime;
typedef struct _P_ { ttime t; int C; int timeinsec; } PaceInfo;

int TotDis, TotPE;
PaceInfo P[6];
int memo[41][601];

//utility(1)
int min(int a, int b) { return (a < b) ? (a) : (b); }

//utility(2)
int ttimetosec(ttime t)
{
	return t.min * 60 + t.sec;
}

//utility(3)
ttime sectotaltime(int secnds)
{
	int min, sec;
	ttime tim;

	min = secnds / 60;
	sec = secnds % 60;
	tim.min = min;
	tim.sec = sec;

	return tim;
}

//main recursion with memoization
ttime mintime(int remainKM, int remainEN)
{
	int i, curenergy, curtime, totaltime[6], minimumtime = ttimetosec((ttime){ 6, 59 })*(TotDis);
	if (memo[remainKM][remainEN]) 
		return sectotaltime(memo[remainKM][remainEN]);
	if (remainKM <= 0)
		return sectotaltime(0);

	if (remainKM > 0 && remainEN >= 0)
	{
		for (i = 1; i <= 5; i++)
		{
			curenergy = P[i].C;
			curtime = P[i].timeinsec;
			if (remainEN - curenergy >= 0)
			{
				totaltime[i] = curtime + ttimetosec(mintime(remainKM - 1, remainEN - curenergy));
				minimumtime = min(minimumtime, totaltime[i]);
			}
		}
	}
	memo[remainKM][remainEN] = minimumtime;
	return sectotaltime(minimumtime);
}

//driver
int main(void)
{
	int tc, T, i, j;
	ttime Answer;
	// The freopen function below opens input.txt file in read only mode, and afterward,
	// the program will read from input.txt file instead of standard(keyboard) input.
	// To test your program, you may save input data in input.txt file,
	// and use freopen function to read from the file when using scanf function.
	// You may remove the comment symbols(//) in the below statement and use it.
	// But before submission, you must remove the freopen function or rewrite comment symbols(//).

	freopen("input.txt", "r", stdin);

	// If you remove the statement below, your program's output may not be rocorded
	// when your program is terminated after the time limit.
	// For safety, please use setbuf(stdout, NULL); statement.

	setbuf(stdout, NULL);
	scanf("%d", &T);
	for (tc = 0; tc < T; tc++)
	{
		Answer.min = Answer.sec = 0;
		scanf("%d %d", &TotPE, &TotDis);
		for (i = 1; i <= 5; i++)
		{
			scanf("%d %d %d", &P[i].t.min, &P[i].t.sec, &P[i].C);
			P[i].timeinsec = ttimetosec(P[i].t);
		}

		/**********************************
		*  Implement your algorithm here. *
		***********************************/
		for (i = 0; i <= 41; i++)
		for (j = 0; j <= 601; j++)
			memo[i][j] = 0;

		Answer = mintime(TotDis, TotPE);
		// Prsint the answer to standard output(screen).
		printf("tc#[%d] %d %d\n", tc+1, Answer.min, Answer.sec);
	}
	_getch();
	return 0;//Your program should return 0 on normal termination.
}
