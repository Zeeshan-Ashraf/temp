/* 
In Practice, You should use the statndard input/output
in order to receive a score properly.
Do not use file input and output. Please be very careful. 

*/
#define	_CRT_SECURE_NO_WARNINGS

#include "stdio.h"

#define	TRUE			1
#define	FALSE			0

#define 	MAX_WIDTH		5
#define	MAX_HEIGHT		12

#define	EMPTY			0
#define	COIN			1
#define	ENEMY			2

#define	HIT_BOUNDRY			1
#define	NO_WAY					2
#define	REACHED_DESTINATION	3

int swMapHeight = 0;
int swMaxCollectedCoins = 0;  /* This variable is updated with max coins after every traversal */
int aswInputMap[MAX_HEIGHT+1][MAX_WIDTH+1] ={0,};
int aswTempMap[MAX_HEIGHT+1][MAX_WIDTH+1] ={0,};

/* Function prototypes */
int TravelDFS(int Xindex,  int Yindex, char IsBombExploded, int swCoinsPickedInThisPath);
void ExplodeBomb(int Yindex, int Xindex);
void ResetBomb(int Yindex, int Xindex);


void main()
{
	int test_case_index;
	int uwNoOfTestcases;
	int i = 0, j = 0;
	int swCoinsPicked = 0;
	/*
	   The freopen function below opens input.txt file in read only mode, and afterward,
	   the program will read from input.txt file instead of standard(keyboard) input.
	   To test your program, you may save input data in input.txt file,
	   and use freopen function to read from the file when using scanf function.
	   You may remove the comment symbols(//) in the below statement and use it.
	   But before submission, you must remove the freopen function or rewrite comment symbols(//).
	 */
	freopen("input.txt", "r", stdin);

	/*
	   If you remove the statement below, your program's output may not be rocorded
	   when your program is terminated after the time limit.
	   For safety, please use setbuf(stdout, NULL); statement.
	 */
	setbuf(stdout, NULL);

	scanf("%d", &uwNoOfTestcases);
	for(test_case_index = 0; test_case_index < uwNoOfTestcases; test_case_index++)
	{
		// read map height
		scanf("%d", &swMapHeight);

		/* memory init */
		swMaxCollectedCoins = -1;
		swCoinsPicked = 0;

		/* read the map input */
		for(i = swMapHeight; i > 0; i--)	/* place row */
		{
			scanf("%d %d %d %d %d", &aswInputMap[i][1], &aswInputMap[i][2], &aswInputMap[i][3], &aswInputMap[i][4], &aswInputMap[i][5]);
		}

		/* Take a backup of input as it is required later when bomb is resetted */
		for(i = swMapHeight; i > 0; i--)	/* place row */
		{
			for(j = 1; j <= MAX_WIDTH; j++)	/* place column */
			{
				aswTempMap[i][j] = aswInputMap[i][j];
			}
		}

		TravelDFS(3 /* start from middle - Column3 */, 0 /* start from row-0*/, FALSE, swCoinsPicked);
		printf("\nCase#%d: %d", (test_case_index+1), swMaxCollectedCoins);
	}
}



int TravelDFS(int Xindex,  int Yindex, char IsBombExploded, int swCoinsPickedInThisPath)
{
	/* Check Boundries */
	if((Xindex <= 0) || (Xindex > MAX_WIDTH))
	{
		return HIT_BOUNDRY;
	}

	/* If coincount went negative, then stop travelling further (Equvalent to Game end) */
	if(swCoinsPickedInThisPath < 0)
	{
		return NO_WAY;
	}

	/* When Airplane has already travelled all rows and reached destination with that path, check the collected coins count and update */
	if(Yindex > swMapHeight)	
	{
		if((swCoinsPickedInThisPath !=0) && (swMaxCollectedCoins < swCoinsPickedInThisPath))
		{
			swMaxCollectedCoins = swCoinsPickedInThisPath;
		}
		return REACHED_DESTINATION;
	}

	/* Check the present cell value and travel further */
	if(aswTempMap[Yindex][Xindex] == COIN)
	{
		swCoinsPickedInThisPath++;
	}
	else if(aswTempMap[Yindex][Xindex] == ENEMY)
	{
		if(IsBombExploded == TRUE)	/* If bomb is already used, then decrement coincount and proceed further */
		{
			swCoinsPickedInThisPath--;
		}
		else	/* If bomb is not used yet, then explode it and travel further */
		{
			/* Explode bomb to kill all enemies in the display region */
			ExplodeBomb(Yindex, Xindex);

			TravelDFS(Xindex, (Yindex+1), TRUE, swCoinsPickedInThisPath);	/* Travel Stright */
			TravelDFS((Xindex-1), (Yindex+1), TRUE, swCoinsPickedInThisPath);	/* Travel Left */
			TravelDFS((Xindex+1), (Yindex+1), TRUE, swCoinsPickedInThisPath);	/* Travel Right */
			
			/* After travelling those paths, call reset bomb to reset the enemies as like before exploding bomb */
			ResetBomb(Yindex, Xindex);
			return NO_WAY;
		}
	}

	/* Travel further in Map towards destination*/
	TravelDFS(Xindex, (Yindex+1), IsBombExploded, swCoinsPickedInThisPath);	/* Travel Stright */
	TravelDFS((Xindex-1), (Yindex+1), IsBombExploded, swCoinsPickedInThisPath);	/* Travel Left */
	TravelDFS((Xindex+1), (Yindex+1), IsBombExploded, swCoinsPickedInThisPath);	/* Travel Right */

	/* If the current cell is enemy and no bombs, then we may have decremented current coin count earlier. reset it back (increment) to original count */
	if((aswTempMap[Yindex][Xindex] == ENEMY) && (IsBombExploded == TRUE))
	{
		swCoinsPickedInThisPath++;
	}
}


void ExplodeBomb(int Yindex, int Xindex)
{
	int i = 0, j = 0;
	int MaxY = (((Yindex+5) < MAX_HEIGHT)? (Yindex+5): MAX_HEIGHT);

	/* Check Boundries */
	if((Yindex <= 0) || (Yindex > MAX_HEIGHT))
	{
		return HIT_BOUNDRY;
	}
	
	for(i = Yindex; i < MaxY; i++)
	{
		for(j = 1; j <= MAX_WIDTH; j++)
		{
			if(aswTempMap[i][j] == ENEMY)
			{
				aswTempMap[i][j] = EMPTY;
			}
		}
	}	
}

void ResetBomb(int Yindex, int Xindex)
{
	int i = 0, j = 0;
	int MaxY = (((Yindex+5) < MAX_HEIGHT)? (Yindex+5): MAX_HEIGHT);

	/* Check Boundries */
	if((Yindex <= 0) || (Yindex > MAX_HEIGHT))
	{
		return HIT_BOUNDRY;
	}
	
	for(i = Yindex; i < MaxY; i++)
	{
		for(j = 1; j <= MAX_WIDTH; j++)
		{
			if(aswInputMap[i][j] == ENEMY)
			{
				aswTempMap[i][j] = aswInputMap[i][j];
			}
		}
	}	
}


