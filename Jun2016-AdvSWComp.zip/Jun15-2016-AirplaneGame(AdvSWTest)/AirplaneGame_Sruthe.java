import java.util.Scanner;

/**
 * @author sruthe.m
 *
 */

public class AirplaneGame_Sruthe {
	static int maxCoins;
	static int N;
	static int[][] originalMap;
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int T=sc.nextInt();
		for(int test_case=0;test_case<T;test_case++)
		{
			maxCoins=-1;
			N=sc.nextInt();
			originalMap=new int[N][5];
			int[][] map=new int[N][5];
			for(int i=0;i<N;i++){
				for(int j=0;j<5;j++){
					originalMap[i][j]=sc.nextInt();
					map[i][j]=originalMap[i][j];
				}
			}		
			calculateMaxCoins(N,2,0,map,false);
			System.out.println("#"+(test_case+1)+" "+maxCoins);		
		}
		sc.close();
	}

	private static void calculateMaxCoins(int ht, int y, int coins, int[][] map,
			boolean blasted) {
		if(ht==0 || coins==-1){
			if(coins>maxCoins){
				maxCoins=coins;
			}
			return;
		}
		
		if(ht-1>-1 && y+1<5) //go right
		{
			if(map[ht-1][y+1]==1) //encountered coin
			{
				calculateMaxCoins(ht-1, y+1, coins+1, map, blasted); 
			}
			else if(map[ht-1][y+1]==2) //encountered enemy
			{
				if(!blasted){
					blasted=true;
					for(int i=ht-1,cnt=0; i>-1 && cnt<5; i--,cnt++){
						for(int j=0;j<5;j++){
							if(map[i][j]==2){
								map[i][j]=0;
							}
						}
					}
					calculateMaxCoins(ht-1, y+1, coins, map, blasted);
					blasted=false; //reset to original values
					for(int i=0;i<N;i++){
						for(int j=0;j<5;j++){
							map[i][j]=originalMap[i][j];
						}
					}
					
				}
				calculateMaxCoins(ht-1, y+1, coins-1, map, blasted); //no blast
			}
			else //encountered 0
			{
				calculateMaxCoins(ht-1, y+1, coins, map, blasted);
			}
		}
		
		if(ht-1>-1 && y-1>-1) //go left
		{
			if(map[ht-1][y-1]==1) //encountered coin
			{
				calculateMaxCoins(ht-1, y-1, coins+1, map, blasted); 
			}
			else if(map[ht-1][y-1]==2) //encountered enemy
			{ 
				if(!blasted){
					blasted=true;
					for(int i=ht-1,cnt=0; i>-1 && cnt<5; i--,cnt++){
						for(int j=0;j<5;j++){
							if(map[i][j]==2){
								map[i][j]=0;
							}
						}
					}
					calculateMaxCoins(ht-1, y-1, coins, map, blasted);
					blasted=false; //reset to original values
					for(int i=0;i<N;i++){
						for(int j=0;j<5;j++){
							map[i][j]=originalMap[i][j];
						}
					}
					
				}
				calculateMaxCoins(ht-1, y-1, coins-1, map, blasted); //no blast
			}
			else //encountered 0
			{
				calculateMaxCoins(ht-1, y-1, coins, map, blasted);
			}
		}
		
		if(ht-1>-1) //stay in same column
		{
			if(map[ht-1][y]==1) //encountered coin
			{
				calculateMaxCoins(ht-1, y, coins+1, map, blasted); 
			}
			else if(map[ht-1][y]==2) //encountered enemy
			{
				if(!blasted){
					blasted=true;
					for(int i=ht-1,cnt=0; i>-1 && cnt<5; i--,cnt++){
						for(int j=0;j<5;j++){
							if(map[i][j]==2){
								map[i][j]=0;
							}
						}
					}
					calculateMaxCoins(ht-1, y, coins, map, blasted);
					blasted=false; //reset to original values
					for(int i=0;i<N;i++){
						for(int j=0;j<5;j++){
							map[i][j]=originalMap[i][j];
						}
					}		
				}
				calculateMaxCoins(ht-1, y, coins-1, map, blasted); //no blast
			}
			else //encountered 0
			{
				calculateMaxCoins(ht-1, y, coins, map, blasted);
			}
		}		
	}
}
