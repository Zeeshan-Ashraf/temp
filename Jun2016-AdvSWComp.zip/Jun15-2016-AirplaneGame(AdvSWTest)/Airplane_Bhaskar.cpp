#include <iostream>
using namespace std;
int game[13][5];
int coins[13][5];
int T,n,ans;
int mov[3][2]={{1,0},{1,1},{1,-1}};

void dfs(int i,int j,int bomb,int coin)
{
	if(coins[i][j]<coin)
		coins[i][j]=coin;
	if(coin<0)
	{
		return;
	}
	if(i > n)
	{
		if(ans<coin)
			ans=coin;
		return;
	}
	int newi,newj;
	for(int k=0;k<3;k++)
	{
		newi = i+mov[k][0];
		newj = j+mov[k][1];
		if(newj>=0&&newj<5)
		{
			if(game[i][j]==1)
				dfs(newi,newj,bomb,coin+1);

			else if(game[i][j]==2)
			{
				if(bomb != -1&&newi-bomb<=5)
					dfs(newi,newj,bomb,coin);
				else 
					dfs(newi,newj,bomb,coin-1);
				if(bomb==-1)
					dfs(newi,newj,i,coin);
			}
			else 
				dfs(newi,newj,bomb,coin);
		}
	}
}

int main()
{
	cin>>T;
	for(int test=0;test<T;test++)
	{
		ans = -1;
		cin>>n;
		for(int i=n;i>0;i--)
			for(int j=0;j<5;j++)
			{
				coins[i][j]=-1;
				cin>>game[i][j];
			}
		dfs(0,2,-1,0);
		cout<<"#"<<test+1<<" "<<ans<<endl;
	}

	return 0;
}