package com.sec.ex;

import java.util.Arrays;
import java.util.Scanner;

public class PlacingTowers {

	static int[][] data; // the matrix that stores the cells
	static int r, c, max; // rows, columns, max value

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int t = sc.nextInt(); // number of test cases
		for (int tc = 0; tc < t; tc++) {
			// since columns were given first, take input wrt. the same
			c = sc.nextInt(); // columns
			r = sc.nextInt(); // rows
			/*
			 * To create the hexagonal matrix, the number of rows are kept TWICE
			 * AS GIVEN IN INPUT. The effect can be seen as below:
			 * 
			 * 1 0 1 0 1 - combined 
			 * 0 1 0 1 0 - row 1 
			 * 2 0 2 0 2 - combined 
			 * 0 2 0 2 0 - row 2 
			 * 3 0 3 0 3 - combined 
			 * 0 3 0 3 0 - row 3
			 * 
			 * traversal of rows 1, 2, 3 can be seen in the matrix as above.
			 * for any valid cell(i,j) (value>0), the 6 neighbors are:
			 * -> i-1,j-1	->i-1,j+1
			 * -> i+1,j-1	->i+1,j+1
			 * -> i-2,j  	->i+2,j
			 * 
			 */
			data = new int[r * 2][c];
			max = 0;
			int rc = 0; // the variable to shift rows. Increment by 2
			// filling values in the matrix
			for (int i = 0; i < r; i++) {
				for (int j = 0; j < c; j++) {
					if (j % 2 == 0)
						data[rc][j] = sc.nextInt();
					else
						data[rc + 1][j] = sc.nextInt();
				}
				rc += 2;
			}
			for (int i = 0; i < r * 2; i++) {
				for (int j = 0; j < c; j++) {
					if (data[i][j] != 0) { // traverse over the valid cells
						checkNeighbors(i, j, new int[6]);
						getMax(i, j, 0, 0, new boolean[r * 2][c]);
					}
				}
			}
			System.out.println("#" + (tc + 1) + " " + max * max);
		}
		sc.close();
	}

	/*
	 * the basic traversal over all 6 neighbors (DFS)
	 */
	private static void getMax(int i, int j, int cost, int count,
			boolean[][] visited) {
		// update the values for chosen cells
		cost += data[i][j];
		count += 1;
		visited[i][j] = true;
		if (count == 4) { //stop traversal and update 'max'
			if (cost > max)
				max = cost;
		} else { //traverse
			if (isSafe(i - 1, j - 1) && !visited[i - 1][j - 1]) {
				getMax(i - 1, j - 1, cost, count, visited);
			}
			if (isSafe(i - 1, j + 1) && !visited[i - 1][j + 1]) {
				getMax(i - 1, j + 1, cost, count, visited);
			}
			if (isSafe(i + 1, j - 1) && !visited[i + 1][j - 1]) {
				getMax(i + 1, j - 1, cost, count, visited);
			}
			if (isSafe(i + 1, j + 1) && !visited[i + 1][j + 1]) {
				getMax(i + 1, j + 1, cost, count, visited);
			}
			if (isSafe(i - 2, j) && !visited[i - 2][j]) {
				getMax(i - 2, j, cost, count, visited);
			}
			if (isSafe(i + 2, j) && !visited[i + 2][j]) {
				getMax(i + 2, j, cost, count, visited);
			}
		}
		visited[i][j] = false; // backtracking
	}

	/*
	 * this method tries to get the maximum value by placing the 4 towers in the
	 * region of 7 hexagonal cells. This can be considered as the initial
	 * assignment of 'max' if a tower is placed in cell (i,j). The values of
	 * neighboring cells are placed in the array 'val' and the 3 maximum
	 * neighbors will be taken for consideration
	 */
	private static void checkNeighbors(int i, int j, int[] val) {
		int sum = data[i][j];
		int index = 0; //
		if (isSafe(i - 1, j - 1)) {
			val[index++] = data[i - 1][j - 1];
		}
		if (isSafe(i - 1, j + 1)) {
			val[index++] = data[i - 1][j + 1];
		}
		if (isSafe(i + 1, j - 1)) {
			val[index++] = data[i + 1][j - 1];
		}
		if (isSafe(i + 1, j + 1)) {
			val[index++] = data[i + 1][j + 1];
		}
		if (isSafe(i - 2, j)) {
			val[index++] = data[i - 2][j];
		}
		if (isSafe(i + 2, j)) {
			val[index++] = data[i + 2][j];
		}
		//implement a sorting algorithm to sort the values
		Arrays.sort(val);
		sum += val[5] + val[4] + val[3];
		if (sum > max)
			max = sum;
	}

	/*
	 * method to apply boundary condition checking
	 */
	private static boolean isSafe(int i, int j) {
		return (i >= 0 && i < r * 2 && j >= 0 && j < c && data[i][j] != 0);
	}
}
