package solution;

import java.util.Scanner;

public class solution {
	public static int n,w,h;
	public static int[][] arr,dupl;
	public static int min;
	public static int[] dx={0,-1,0,1};
	public static int[] dy={-1,0,1,0};
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		int test_case=sc.nextInt();
		for(int tc=1;tc<=test_case;tc++){
			min=Integer.MAX_VALUE;
			n=sc.nextInt();
			w=sc.nextInt();
			h=sc.nextInt();
			arr=new int[h][w];
			dupl=new int[h][w];

			//reading input
			for(int i=0;i<h;i++)
				for(int j=0;j<w;j++)
					arr[i][j]=sc.nextInt();

			//permutation
			for(int i=0;i<w;i++){
				if(n==1){  //for one bomb
					
					for(int u=0;u<h;u++)		//storing in duplicate array
						for(int v=0;v<w;v++)
							dupl[u][v]=arr[u][v];
					
					helper(i,-1,-1,-1);
					calculateRemaining();
					
					for(int u=0;u<h;u++)		//restoring back
						for(int v=0;v<w;v++)
							arr[u][v]=dupl[u][v];
					continue;
				}
				for(int j=0;j<w;j++){
					if(n==2){ //for two bombs
						
						for(int u=0;u<h;u++)
							for(int v=0;v<w;v++)
								dupl[u][v]=arr[u][v];
						
						helper(i,j,-1,-1);
						calculateRemaining();
						
						for(int u=0;u<h;u++)
							for(int v=0;v<w;v++)
								arr[u][v]=dupl[u][v];
						continue;
					}
					for(int k=0;k<w;k++){
						if(n==3){	//for three bombs
							
							for(int u=0;u<h;u++)
								for(int v=0;v<w;v++)
									dupl[u][v]=arr[u][v];
							
							helper(i,j,k,-1);
							calculateRemaining();
							
							for(int u=0;u<h;u++)
								for(int v=0;v<w;v++)
									arr[u][v]=dupl[u][v];
							continue;
						}
						for(int l=0;l<w;l++){ //for four bombs
							
							for(int u=0;u<h;u++)
								for(int v=0;v<w;v++)
									dupl[u][v]=arr[u][v];
							
							helper(i,j,k,l);
							calculateRemaining();
							
							for(int u=0;u<h;u++)
								for(int v=0;v<w;v++)
									arr[u][v]=dupl[u][v];
						}
					}
				}
			}
			System.out.println("#"+tc+" "+min);
		}
		sc.close();
	}
	
	public static void helper(int i,int j,int k,int l){
		if(i!=-1){
			for(int a=0;a<h;a++){
				if(arr[a][i]!=0){  //dropping bomb on the first numbered(1-9) block in that column
					bomb(a,i); //blasting the blocks 
					reconstruct(); //reconstructing the array after the blasts
					break;
				}
			}
		}
		if(j!=-1){
			for(int a=0;a<h;a++){
				if(arr[a][j]!=0){	
					bomb(a,j);
					reconstruct();
					break;
				}
			}
		}
		if(k!=-1){
			for(int a=0;a<h;a++){	
				if(arr[a][k]!=0){	
					bomb(a,k);
					reconstruct();
					break;
				}
			}
		}
		if(l!=-1){
			for(int a=0;a<h;a++){
				if(arr[a][l]!=0){	
					bomb(a,l);
					reconstruct();
					break;
				}
			}
		}
	}
	
	public static void bomb(int i,int j){
		int temp=arr[i][j];
		
			arr[i][j]=-1;

		for(int k=0;k<temp-1;k++){	//blasting in four directions based on the block value
			for(int x=0;x<4;x++){
				int m=i+(k+1)*dx[x];
				int n=j+(k+1)*dy[x];
				if(issafe(m,n)){
					bomb(m,n);
				}
			}
		}
	}
	
	public static boolean issafe(int m,int n){
		if(m>=0 && m<h && n>=0 && n<w)
			return true;
		else
			return false;
	}
	
	public static void reconstruct(){
		for(int i=0;i<w;i++){
			for(int j=0;j<h;j++){
				if(arr[j][i]==-1){
					int temp=j;
					for(int k=j-1;k>=0;k--){	//moving down the blocks after blast if empty
						arr[j--][i]=arr[k][i];
						arr[k][i]=0;
					}
					j=temp;
				}
			}
		}
		
		for(int i=0;i<h;i++)
			for(int j=0;j<w;j++)
				if(arr[i][j]==-1)
					arr[i][j]=0;
	}
	
	public static void calculateRemaining(){
		int count=0;
		for(int i=0;i<h;i++){
			for(int j=0;j<w;j++){
				if(arr[i][j]!=0){
					count++;
				}
			}
		}
		if(count<min)
			min=count;
	}
}