import java.io.FileInputStream;
import java.util.Scanner;

class Algorithm {
    static int Answer;
    static char[] characters;   //Input array
    static int size;            //Input size
    static String[] halfWords;  //List of permutations of input
    static int halfWordCount;   //Count of permutations of input
    
    //Build all permutations of input characters and store it
    public static void buildWords(String currentString){
        int len = currentString.length();
        if(len == size){
            boolean isAlreadyThere = false;
            for(int i = 0; i < halfWordCount; ++i){
                if(halfWords[i] == currentString){
                    isAlreadyThere = true;
                    i = halfWordCount;
                }
            }
            if(!isAlreadyThere){
                halfWords[halfWordCount++] = currentString;
            }
        } else {
            for(int i = 0; i < size; ++i)
                //NOTE indexOf is not allowed in test. Basic implementation of the same is OK.
                if(currentString.indexOf(characters[i]) == -1)
                    buildWords(currentString + characters[i]);
        }
    }
    
    //Given part of an IP address as a string, return its integer value
    //If the string is "00" or "000" it returns -1 - this is to help with validation
    public static int getIntValue(String in){
        switch(in.length()){
            case 1:
                return in.charAt(0) - 48;
            case 2:
                if(in.charAt(0) == '0' && in.charAt(1) == '0')
                    return -1;
                else
                    return ((in.charAt(0) - 48) * 10) + (in.charAt(1) - 48);
            case 3:
                if(in.charAt(0) == '0' && in.charAt(1) == '0' && in.charAt(2) == '0')
                    return -1;
                else
                    return ((in.charAt(0) - 48) * 100) + ((in.charAt(1) - 48) * 10) + (in.charAt(2) - 48);
            default:
                return -1;
        }
    }
    
    //Check if part is between 0 and 255 - if part is 00 or 000 i value will be -1 so it will be rejected
    public static boolean check(int i){
        return i >= 0 && i <= 255;
    }
    
    //If part starts with 0, and it has length more than 1, the part (and consequently the IP address) is invalid
    public static boolean leadingZero(String in){
        if(in.length() > 1)
            return in.charAt(0) == '0';
        else
            return false;
    }
    
    //Given 4 parts of an IP address, check if it has a leading 0 or if each part is valid and increment answer if valid.
    public static void checkIfValidIp(String ip1, String ip2, String ip3, String ip4){
        if(leadingZero(ip1) || leadingZero(ip2) || leadingZero(ip3) || leadingZero(ip4)){
            return;
        }
        int i1 = getIntValue(ip1);
        int i2 = getIntValue(ip2);
        int i3 = getIntValue(ip3);
        int i4 = getIntValue(ip4);
        if(check(i1) && check(i2) && check(i3) && check(i4))
            Answer++;
    }
    
    //Generate 'parts' of the IP address using nested loops, and validate
    public static void validate(String ip){
        int len = ip.length();
        if(len == 4){
            Answer++;
        } else {
            String ip1, ip2, ip3, ip4;
            for(int i = 1; i < len; ++i){
                for(int j = i+1; j < len; ++j){
                    for(int k = j+1; k < len; ++k){
                        //NOTE substring is not allowed in test. Basic implementation of same is OK.
                        ip1 = ip.substring(0, i);
                        ip2 = ip.substring(i, j);
                        ip3 = ip.substring(j, k);
                        ip4 = ip.substring(k, len);
                        //Instead of making a check here for length, the limits for i, j and k can be altered instead to 
                        //keep loops shorter
                        if(ip1.length() < 4 && ip2.length() < 4 && ip3.length() < 4 && ip4.length() < 4){
                            checkIfValidIp(ip1, ip2, ip3, ip4);
                        }
                    }
                }
            }
        }
    }
    
    //Generate IP addresses. Note that there are two ways to generate pallindromic IP addresses for some length values.
    public static void getIpAddressesAndValidate(){
        String currentIp = "";
        for(int i = 0; i < halfWordCount; ++i){
            currentIp = halfWords[i];
            //Mirror and append each permutation
            for(int j = currentIp.length() - 1; j >= 0; --j)
                currentIp += currentIp.charAt(j);
            validate(currentIp);
            currentIp = halfWords[i];
            //Mirror and append 1 character short of each permutation
            for(int j = currentIp.length() - 2; j >= 0; --j)
                currentIp += currentIp.charAt(j);
            validate(currentIp);
        }
    }
    
    public static void main(String args[]) throws Exception {
        Scanner sc = new Scanner(System.in);
//        Scanner sc = new Scanner(new FileInputStream("input.txt"));

        int T = sc.nextInt();
        for(int test_case = 0; test_case < T; test_case++) {
            size = sc.nextInt();
            characters = new char[size];
            halfWordCount = 0;
            halfWords = new String[720];
            
            for(int i = 0; i < size; ++i){
                characters[i] = sc.next().charAt(0);
            }
            
             Answer = 0;
             
             /*
              * General approach : Build all permutations of input and store.
              * For each permutation, construct pallindromic IP address and validate it.
              */
             
             for(int i = 0; i < size; ++i){
                 buildWords("" + characters[i]);
             }
             
             getIpAddressesAndValidate();
             
            System.out.println("#"+(test_case+1) + " " + Answer);
        }
    }
}
