#include <stdio.h>

int T, N, C, f, r, vis[25][25], mat[25][25], dist[25][25], el[25][25];
struct pos { int x, y; } q[405];

void enq(pos p) { q[r++] = p; }
pos deq() { return q[f++]; }
bool qempty() { return f == r; }

int bfs(pos rcpos)
{
	int mx = -1;
	enq(rcpos);    //adding to queue
	dist[rcpos.x][rcpos.y] = 0;
	while (!qempty())
	{
		pos from = deq(), to[4];  //from = current location (dequeue) and to = all 4 directions from current location
		to[0].x = from.x+1, to[0].y = from.y;
		to[1].x = from.x-1, to[1].y = from.y;
		to[2].x = from.x, to[2].y = from.y+1;
		to[3].x = from.x, to[3].y = from.y-1;
		for (int i = 0; i < 4; ++i)
		{
			int tx = to[i].x, ty = to[i].y;
			if (tx < N && ty < N && tx >= 0 && ty >= 0 && !vis[tx][ty] && mat[tx][ty])  //within boundary, not visited and that location is one.
			{
				vis[tx][ty] = 1; 
				dist[tx][ty] = dist[from.x][from.y] + 1; 
				enq(to[i]);   //add to queue

				if (el[tx][ty] && dist[tx][ty] > mx)  //if it is element and the distance is > max.
					mx = dist[tx][ty];
			}
		}
	}
	return mx == -1 ? 10000004 : mx;  // mx=-1 condition is to address if the RC is placed like island e\ie., none of the element was reachable (surrounded by zero)
}

int main()
{
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d%d", &N, &C);
		for (int k = 0; k < N; ++k) for (int l = 0; l < N; ++l) el[k][l] = 0;
		for (int i = 0; i < C; ++i)
		{
			pos p;
			scanf("%d%d", &p.x, &p.y);
			el[p.x-1][p.y-1] = 1;
		}
		for (int i = 0; i < N; ++i) for (int j = 0; j < N; ++j) scanf("%d", &mat[i][j]);
		int mn = 1000000004, tmp;
		for (int i = 0; i < N; ++i)
			for (int j = 0; j < N; ++j)
			{
				pos rcpos; rcpos.x = i, rcpos.y = j;
				if (mat[rcpos.x][rcpos.y] && !el[rcpos.x][rcpos.y])  //RCs cannot be buildt on ELs or on Zero(ie. no roads)
				{
					for (int k = 0; k < N; ++k) for (int l = 0; l < N; ++l) vis[k][l] = 0; 
					f = r = 0;
					tmp = bfs(rcpos);  //bfs done for every RC location
					if (tmp < mn) mn = tmp;
				}
			}
		printf("%d\n", mn);
	}
	return 0;
}