//Indu Naganathan
import java.io.File;
import java.util.Scanner;

public class Solution 
{
	static int N, C, front, rear, steps, ans;
	static int mine_loc[][], matrix[][], visited[][];
	static int queueX[], queueY[], queueC[], count[];

	private static void enQueue(int x, int y, int c)
	{
		if(rear < queueX.length-1)
		{
			rear++;

			queueX[rear] = x;
			queueY[rear] = y;
			queueC[rear] = c;
			
			visited[x][y] = 1;
		}
	}

	private static int[] deQueue()
	{
		int[] ret = new int[3];
		if(front <= rear)
		{
			ret[0] = queueX[front];
			ret[1] = queueY[front];
			ret[2] = queueC[front];

			front++;
		}
		return ret;
	}

	private static boolean isEmpty()
	{
		if(front > rear)
		{
			return true;
		}
		return false;
	}

	private static boolean isSafe(int i, int j)
	{
		if((i >= 0) && (i < N) && (j >= 0) && (j < N) && (matrix[i][j] != 0) && (visited[i][j] != 1))
		{
			return true;
		}
		return false;
	}

	private static void findBestPath(int i, int j, int x, int y, int step) 
	{
		enQueue(i, j, step);

		while(!isEmpty())
		{
			int[] ret = deQueue();

			int a = ret[0];
			int b = ret[1];
			int c = ret[2];

			if((a == x) && (b == y)) //destination
			{
				if(steps == 0)
				{
					steps = c;
				}
				else
				{
					if(c < steps)
					{
						steps = c;
					}
				}
				return;
			}

			//left
			if(isSafe(a, b-1))
			{
				enQueue(a, b-1, c+1);
			}
			
			//right
			if(isSafe(a, b+1))
			{
				enQueue(a, b+1, c+1);
			}
			
			//up
			if(isSafe(a+1, b))
			{
				enQueue(a+1, b, c+1);
			}
			
			//down
			if(isSafe(a-1, b)) 
			{
				enQueue(a-1, b, c+1);
			}
		}
	}

	private static void clearVisited() 
	{
		steps = 0;

		queueX = new int[N*N];
		queueY = new int[N*N];
		queueC = new int[N*N];

		front = 0;
		rear = -1;

		visited = new int[N][N];
	}
	
	private static int findMin(int[] temp) 
	{
		int min = temp[0];
		for(int i=1; i<temp.length; i++)
		{
			if((temp[i] != 0) && (temp[i] < min))
			{
				min = temp[i];
			}
		}
		return min;
	}
	
	private static int findMax(int[] temp)
	{
		//This is ensure that we are picking the camping location, which has a valid path to all the 'C' mining locations
		for(int i=0; i<temp.length; i++)
		{
			if(temp[i] == 0)
			{
				return 0;
			}
		}
		
		int max = temp[0];
		for(int i=1; i<temp.length; i++)
		{
			if(temp[i] > max)
			{
				max = temp[i];
			}
		}
		return max;
	}

	public static void main(String args[]) throws Exception
	{
		Scanner sc = new Scanner(new File("input.txt"));

		int T = sc.nextInt(); //Number of Test cases

		for(int testCase = 1; testCase <= T; testCase++)
		{
			ans = 0; //Reset answer for each TC

			N = sc.nextInt(); //Height and Width of the region of search
			C = sc.nextInt(); //Mine count
			
			mine_loc = new int[C][2]; //Mine location data
			matrix = new int[N][N]; //Region data
			
			count = new int[N*N]; //Reset the all best paths data for each TC

			//Reading mine_loc data
			for(int i = 0; i < C; i++)
			{
				mine_loc[i][0] = sc.nextInt() - 1; //To align data.x to the relative index
				mine_loc[i][1] = sc.nextInt() - 1; //To align data.y to the relative index
			}

			//Reading region data 
			for(int i = 0; i < N; i++)
			{
				for(int j = 0; j < N; j++)
				{
					matrix[i][j] = sc.nextInt();
				}
			}

			//Set the mine location data on the region matrix
			for(int i = 0; i < C; i++)
			{
				matrix[mine_loc[i][0]][mine_loc[i][1]] = 2;
			}
			
			int c = 0; //Control variable for count array
			for(int i = 0; i < N; i++)
			{
				for(int j = 0; j < N; j++)
				{
					if(matrix[i][j] == 1)
					{
						int temp[] = new int[C];
						for(int k = 0; k < C; k++)
						{
							clearVisited();
							findBestPath(i, j, mine_loc[k][0], mine_loc[k][1], 0); //startX , startY, endX, endY, step
							if(steps <= 0)
							{
								break;
							}
							else
							{
								temp[k] = steps;
							}
						}
						count[c] = findMax(temp);
						c++;
					}
				}
			}
				
			ans = findMin(count);
			System.out.println("#" + testCase + " " + ans);
		}	
		sc.close();
	}
}




