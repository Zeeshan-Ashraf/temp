package com.samsung.test;    //Saurabh - SWAT - SW Agile Team

import java.io.FileInputStream;
import java.util.Scanner;

public class AutoFuelRobot {

	static int Answer = 999999;
	static int[] carStation = null;
	static boolean[] visited = null;
	static int cars = 0;
	
	public static void main(String[] args) throws Exception {
		
		System.setIn(new FileInputStream("D:\\TestWS\\Test\\AutoFuelRobot.txt"));
		Scanner scn = new Scanner(System.in);
		
		int T = scn.nextInt();
		
		for(int testCase = 1;testCase <= T;testCase++)
		{
			cars = scn.nextInt();
			
			//Took extra cell for Gasoline and Diesel Station.
			carStation = new int[cars + 2];
			visited = new boolean[cars + 2];
			
			carStation[0] = 3; // Dummy Data for Gasoline Station
			carStation[carStation.length - 1] = 4; //Dummy Data for Diesel Station
			Answer = 999999; // Some big vale for answer.
			
			//Filled the car place from index 1 to array length - 1, so that can get the moved distance easily. 
			for(int i = 1;i<carStation.length -1;i++)
			{
				carStation[i] = scn.nextInt();
			}
					
			//Recursive and backtracking for all possible paths to get the minimum distance.
			calculateDistance(0,0,2,0,0);
			
			System.out.println("#" + testCase + " " + Answer);
		}

		scn.close();
	}
	
	private static void calculateDistance(int distanceMoved,int index,int gasoline,int diesel,int filledCount) // index is current pos of robot
	{
		//Proceed if distance moved is less than previous minimum distance.
		if(distanceMoved < Answer)
		{
			//Update the answer if all cars are filled.
			if(filledCount == cars)
			{
				Answer = distanceMoved;
				visited[index]= false;
				return;
			}
			
			for(int i = 0;i<carStation.length;i++)
			{
				//Check for the filled cars.
				if(!visited[i] && i != index)
				{
					//Check for Gasoline and car type
					if(gasoline > 0 && carStation[i] == 1)  //if we have enough gas and car type is gasoline
					{
						visited[i] = true;
						calculateDistance(distanceMoved + getAbsoluteValue(i, index),i,gasoline - 1,diesel,filledCount + 1);
						visited[i] = false;
					}
					
					//Check if its gasoline station and its not coming from diesel station , otherwise it will result in infinite loop.
					if(i == 0 && index != carStation.length -1)
					{
						//As robot can visit fuel station any time in the path so not considered as visited.
						calculateDistance(distanceMoved + getAbsoluteValue(i, index),i,2,0,filledCount);
					}
					
					//Check for Diesel and car type
					if(diesel > 0 && carStation[i] == 2)
					{
						visited[i] = true;
						calculateDistance(distanceMoved + getAbsoluteValue(i, index),i,gasoline,diesel - 1,filledCount + 1);
						visited[i] = false;
					}
					
					//Can go to diesel station from Gasoline station.
					if(i == carStation.length - 1)
					{
						//As robot can visit fuel station any time in the path so not considered as visited.
						calculateDistance(distanceMoved + getAbsoluteValue(i, index),i,0,2,filledCount);
					}
				}
			}
		}
	}
	
	//To get the absolute value as index robot can move left and right both sides.
	//If higher index is subtracted from lower index result is negative , so taking absolute value.
	private static int getAbsoluteValue(int a,int b)
	{
		int val = a - b;
		return val < 0 ? val * -1 : val;
	}

}
